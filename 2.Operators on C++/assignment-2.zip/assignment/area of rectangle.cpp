#include<iostream>
#include<cmath>
using namespace std;
int main() {
	float a;
	float b;
	float area;
	cout << "GIVE THE LENGTH OF A and B" << endl;
	cin >> a;
	cin >> b;
	area = a * b;
	cout << "AREA IS " << area << endl;
	system("pause");
	return 0;
}
/*
Assigbment ? 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area of rectangle
*/