#include<iostream>
using namespace std;
int main() {
	float a, b;
	float area;
	cout << "GIVE THE LENGTH OF A,B" << endl;
	cin >> a;
	cin >> b;
	area = a * b / 2;
	cout << "AREA IS " << area << endl;
	system("pause");
	return 0;
}
/*
Assigbment - 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area of Right Triangle
*/