#include<iostream>
using namespace std;
int main() {
	float a;
	float area;
	cout << "GIVE THE LENGTH OF A" << endl;
	cin >> a;
	area = sqrt(3) / 4 * a * a;
	cout << "AREA IS " << area << endl;
	system("pause");
	return 0;
}
/*
Assigbment ? 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area of Equilateral Triangle
*/