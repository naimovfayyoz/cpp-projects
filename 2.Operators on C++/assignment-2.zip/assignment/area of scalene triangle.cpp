#include<iostream>
using namespace std;
int main() {
	float a, b, c;
	float p;
	float area;
	cout << "GIVE THE LENGTH OF A,B,C" << endl;
	cin >> a;
	cin >> b;
	cin >> c;
	p = ((a + b + c) / 2);
	area = sqrt((p * (p - a) * (p - b) * (p - c)));
	cout << "AREA IS " << area << endl;
	system("pause");
	return 0;
}
/*
Assigbment � 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area of Scalene Triangle
*/