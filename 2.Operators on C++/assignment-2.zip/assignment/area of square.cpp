#include<iostream>
#include<cmath>
using namespace std;
int main() {
	float a;
	float b;
	float area;
	cout << "GIVE THE LENGTH OF A " << endl;
	cin >> a;
	area = a * a;
	cout << "AREA IS " << area << endl;
	system("pause");
	return 0;
}
/*
Assigbment ? 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area of square
*/