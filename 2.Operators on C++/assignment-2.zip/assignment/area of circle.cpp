#include<iostream>
using namespace std;
int main() {
	float PI = 3.14;
	float R;
	cout << "GIVE THE VALUE FOR RADIUS TO CALCULATE THE AREA OF CIRCLE" << endl;
	cin >> R;
	cout << " THE AREA OF CIRCLE IS " << R * R * PI << endl;
	cout << "GIVE THE VALUE FOR RADIUS TO CALCULATE THE CIRCUMFERENCE OF CIRCLE" << endl;
	cin >> R;
	cout << " THE CIRCUMFERENCE OF CIRCLE IS " << 2 * R * PI << endl;
	system("pause");
	return 0;
}
/*
Assigbment � 2
UID: 1910071
Name:Fayyoz Naimov
Program Statement :CALCULATE Area and Circumference of Circle
*/